"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
exports.__esModule = true;
exports.AppModule = void 0;
var platform_browser_1 = require("@angular/platform-browser");
var core_1 = require("@angular/core");
// routing
var router_1 = require("@angular/router");
// formularios
var forms_1 = require("@angular/forms");
var store_1 = require("@ngrx/store");
var effects_1 = require("@ngrx/effects");
var store_devtools_1 = require("@ngrx/store-devtools");
// components
var app_component_1 = require("./app.component");
var destino_viaje_component_1 = require("./destino-viaje/destino-viaje.component");
var lista_destinos_component_1 = require("./lista-destinos/lista-destinos.component");
var destino_detalle_component_1 = require("./destino-detalle/destino-detalle.component");
var form_destino_viaje_component_1 = require("./form-destino-viaje/form-destino-viaje.component");
var destinos_api_client_model_1 = require("./models/destinos-api-client.model");
var destinos_viajes_state_model_1 = require("./models/destinos-viajes-state.model");
// Configuramos las rutas que vamos a usar en el navegador
var routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: lista_destinos_component_1.ListaDestinosComponent },
    { path: 'destino', component: destino_detalle_component_1.DestinoDetalleComponent },
];
var reducers = {
    destinos: destinos_viajes_state_model_1.reducerDestinosViajes
};
var reducersInitialState = {
    destinos: destinos_viajes_state_model_1.initializeDestinosViajesState()
};
// redux fin init
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            declarations: [
                app_component_1.AppComponent,
                destino_viaje_component_1.DestinoViajeComponent,
                lista_destinos_component_1.ListaDestinosComponent,
                destino_detalle_component_1.DestinoDetalleComponent,
                form_destino_viaje_component_1.FormDestinoViajeComponent,
            ],
            imports: [
                platform_browser_1.BrowserModule,
                forms_1.FormsModule,
                forms_1.ReactiveFormsModule,
                router_1.RouterModule.forRoot(routes),
                store_1.StoreModule.forRoot(reducers, { initialState: reducersInitialState }),
                effects_1.EffectsModule.forRoot([destinos_viajes_state_model_1.DestinosViajesEffects]),
                store_devtools_1.StoreDevtoolsModule.instrument()
            ],
            providers: [
                destinos_api_client_model_1.DestinosApiClient
            ],
            bootstrap: [app_component_1.AppComponent]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
